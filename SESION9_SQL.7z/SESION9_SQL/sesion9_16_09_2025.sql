--  Parte 1: Realizar consultas con INNER JOIN, LEFT JOnIN en tablas de ejemplo.
-- Ejercicio 1 (INNER JOIN): Mostrar solo los clientes que tienen cuentas asociadas. (Seleccionar Nombre como Cliente, TipoCuenta, Saldo). Utiliza las tablas Clientes y Cuentas
USE  BANCODB;
SELECT * FROM CLIENTES;  

SELECT  cli.nombre as cliente,
        cu.tipocuenta,
        cu.saldo
FROM CLIENTES cli
INNER JOIN cuentas cu on cli.clienteid=cu.clienteid;

-- Ejercicio 2 (LEFT JOIN): Mostrar todos los clientes, incluyendo aquellos que no tienen cuenta bancaria. (Seleccionar Nombre como Cliente, TipoCuenta, Saldo). Utiliza las tablas Clientes y Cuentas
SELECT  cli.nombre as cliente,
        cu.tipoCuenta,
        cu.saldo
FROM CLIENTES cli
LEFT JOIN cuentas cu on cli.clienteid=cu.clienteid;
-- Ejercicio 3: Realiza una consulta para mostrar el total de saldo y el número de clientes por sucursal. Utiliza INNER JOIN entre las tablas Sucursales y Cuentas, agrupando por el nombre de la sucursal (Seleccionar Nombre de la sucursal como Sucursal, la suma del saldo como TotalSaldo y el número de clientes como NumeroDeClientes)
select * from sucursales;
select * from cuentas;

select s.nombre as sucursal,
       sum(c.saldo) as totalsaldo, 
       count(distinct c.Clienteid) as  numerodeclientes
from Sucursales s
inner join Cuentas c on s.sucursalid=c.sucursalid
group by nombre;

-- Ejercicio 4: Realiza una consulta para mostrar el número de cuentas asociadas a cada cliente, incluyendo a aquellos que no tienen cuentas. Utiliza LEFT JOIN entre las tablas Clientes y Cuentas, agrupando por el nombre del cliente. (Selecciona el nombre del cliente como Cliente y el número de cuentas como NumerodeCuentas)

select cli.clienteid,
      nombre as cliente,
      count(cuentaid) as numerodecuentas
from clientes cli
left join cuentas cu on cli.clienteid =cu.clienteid
group by cli.clienteid, nombre;

-- Ejercicio 5: Realiza una consulta para mostrar las cuentas de tipo "Ahorros" asociadas a cada cliente. Utiliza LEFT JOIN entre las tablas Clientes y Cuentas, y agrupa por el nombre del cliente. (Selecciona el nombre del cliente como Cliente TipoCuenta y Saldo).

select cli.Nombre as cliente,
	   cu.tipocuenta,
       sum(cu.Saldo) as Saldoahorros
from Clientes cli
left join Cuentas cu on cli.ClienteID=cu.ClienteID
where Tipocuenta="Ahorros"
group by cli.Nombre, cu.Tipocuenta;

-- Parte 2: Combinaciones de JOIN
-- Ejercicio 1: Realiza una consulta para mostrar los nombres de los clientes que han realizado ambos tipos de transacciones: "Depósito" y "Retiro". Utiliza INNER JOIN entre las tablas Clientes, Cuentas y Transacciones, y filtra por los tipos de transacción "Depósito" y "Retiro". Luego, utiliza HAVING para asegurarte de que cada cliente tenga al menos una transacción de cada tipo.
-- Ejercicio 2: Realiza una consulta para mostrar los detalles de las transacciones realizadas en la "Sucursal Centro". La consulta debe incluir el ID de la transacción, la fecha de la transacción, el monto, el nombre del cliente como cliente, el tipo de cuenta y el nombre de la sucursal. Utiliza INNER JOIN entre las tablas Transacciones, Cuentas, Clientes y Sucursales, filtrando por el nombre de la sucursal "Sucursal Centro".
--  para mostrar el total de depósitos y retiros realizados por cada cliente en cada sucursal, desglosando los montos por tipo de transacción. Utiliza INNER JOIN entre las tablas Clientes, Cuentas, Transacciones y Sucursales, y utiliza CASE para separar los montos de depósitos y retiros. Los resultados deben estar agrupados por cliente, tipo de cuenta y sucursal.
Ejercicio 3: Realiza una consulta
 select cli.nombre , tipocuenta 
        -- count(distinct numerotipotransaccion) as numeroTipoDeTransacciones
 from transacciones trx
 inner join cuentas cu on trx.cuentaid=cu.cuentaid
 inner join clientes cli on cli.clienteid=cu.clienteid
 where tipotransaccion IN('Depósito', 'Retiro')
  group by cli.Nombre;
 having count(distinct  numeroTipoDeTransacciones) =2

 
 select cli.nombre as cliente,
        s.nombre as sucursal,
        cu.tipocuenta ,
        sum(case when tipotransaccion="deposito"then trx.monto else 0 end) as totaldepositos,
		sum(case when tipotransaccion="retiro"then trx.monto else 0 end) as totalretiros
 from clientes cli
 inner join cuentas cu on cli.clienteid=cu.clienteid
 inner join transacciones trx on cu.cuentaid = trx.cuentaid
 inner join sucursales s on cu.sucursalid = s.sucursalid
 group by cli.nombre, s.nombre,tipocuenta;
