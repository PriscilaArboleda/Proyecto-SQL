USE BANCODB;
-- Ejercicio 1 (INNER JOIN): Mostrar solo los clientes que tienen cuentas asociadas. 
-- (Seleccionar Nombre como Cliente, TipoCuenta, Saldo). Utiliza las tablas Clientes y Cuentas
select * from clientes; 

SELECT cli.Nombre as Cliente, 
	cu.TipoCuenta,
    cu.Saldo
FROM Clientes cli
INNER JOIN Cuentas cu ON cli.clienteID = cu.clienteID;

-- Ejercicio 2 (LEFT JOIN): Mostrar todos los clientes, incluyendo aquellos que no tienen cuenta bancaria. 
-- (Seleccionar Nombre como Cliente, TipoCuenta, Saldo). Utiliza las tablas Clientes y Cuentas
SELECT * FROM CUENTAS;
SELECT * FROM CLIENTES;

SELECT cli.Nombre as Cliente,
       cu.Tipocuenta,
       cu.Saldo
FROM Clientes cli
LEFT join Cuentas cu ON cli.clienteID = cu.clienteID;

-- Ejercicio 3: Realiza una consulta para mostrar el total de saldo y el número de clientes por sucursal.
-- Utiliza INNER JOIN entre las tablas Sucursales y Cuentas, 
-- agrupando por el nombre de la sucursal (Seleccionar Nombre de la sucursal como Sucursal, 
-- la suma del saldo como TotalSaldo y el número de clientes como NumeroDeClientes)
SELECT * FROM SUCURSALES;
SELECT * FROM CUENTAS;

SELECT s.Nombre AS Sucursal,
       sum(saldo) as totalSaldo,
       count(*) as NumeroDeClientes
FROM SUCURSALES s
INNER JOIN cuentas c ON s.sucursalID = c.SucursalID
GROUP BY s.Nombre

-- Ejercicio 4: Realiza una consulta para mostrar el número de cuentas asociadas a cada cliente, 
-- incluyendo a aquellos que no tienen cuentas. Utiliza LEFT JOIN entre las tablas Clientes y Cuentas,
--  agrupando por el nombre del cliente.
--  (Selecciona el nombre del cliente como Cliente y el número de cuentas como NumerodeCuentas)

select * from clientes;
select * from cuentas;

select cli.Nombre, count(CuentaID) AS NumeroCuenta
from clientes cli
left join  cuentas cu on cli.clienteId= cu.clienteID
group by cli.Nombre

-- Ejercicio 5: Realiza una consulta para mostrar las cuentas de tipo
-- "Ahorros" asociadas a cada cliente. Utiliza LEFT JOIN entre las tablas Clientes y Cuentas, 
-- y agrupa por el nombre del cliente. (Selecciona el nombre del cliente como Cliente TipoCuenta y Saldo).
select * from clientes;
select * from cuentas;

select cli.nombre as cliente,
       tipocuenta,
       sum(saldo)
from clientes cli
left join cuentas cu on cli.clienteID=cu.clienteID
where tipoCuenta ='Ahorros'
GROUP BY cli.nombre, tipocuenta;

--  Parte 2: Combinaciones de JOIN
-- Ejercicio 1: Realiza una consulta para mostrar los nombres de los clientes que han realizado 
-- ambos tipos de transacciones: "Depósito" y "Retiro". Utiliza INNER JOIN entre las tablas Clientes,
-- Cuentas y Transacciones, y filtra por los tipos de transacción "Depósito" y "Retiro". Luego, 
-- utiliza HAVING para asegurarte de que cada cliente tenga al menos una transacción de cada tipo.

select * from clientes;
select * from cuentas;
select * from transacciones;

select cli.nombre, tra.tipoTransaccion, count(*)
from 
clientes AS cli
inner join
cuentas cu on cli.clienteID=cu.clienteID
inner join 
transacciones tra on cu.cuentaID=tra.cuentaID
where 
tra.tipotransaccion in('Depósito', 'retiro')
group by cli.nombre, tra.tipoTransaccion
HAVING count(case when tra.tipoTransaccion="Depósito" then 1 end)>=1
and count(case when tra.tipoTransaccion ="Retiro" then 1 end) >=1;

-- Ejercicio 2: Realiza una consulta para mostrar los detalles de las transacciones realizadas 
-- en la "Sucursal Centro". La consulta debe incluir el ID de la transacción, la fecha de la transacción, 
-- el monto, el nombre del cliente como cliente, el tipo de cuenta y el nombre de la sucursal. Utiliza INNER JOIN
-- entre las tablas Transacciones, Cuentas, Clientes y Sucursales, filtrando por el nombre de la sucursal "Sucursal Centro".

select * from transacciones;
select * from clientes;
select * from sucursales;
select * from cuentas;

select  t.transaccionID,
        t.fechaTransaccion,
        t.Monto,
        cli.Nombre,
        c.tipoCuenta,
        s.Nombre
from 
transacciones as t
inner join cuentas as c on t.cuentaid=c.cuentaid
inner join clientes as cli on c.clienteid=cli.clienteid
inner join sucursales as s on c.sucursalid=s.sucursalid
where 
s.nombre='sucursal centro';


-- Ejercicio 3: Realiza una consulta para mostrar el total de depósitos y retiros realizados
-- por cada cliente en cada sucursal, desglosando los montos por tipo de transacción.
-- Utiliza INNER JOIN entre las tablas Clientes, Cuentas, Transacciones y Sucursales,
-- y utiliza CASE para separar los montos de depósitos y retiros. Los resultados deben estar 
-- agrupados por cliente, tipo de cuenta y sucursal.

select * from transacciones;
SELECT * FROM SUCURSALES;

select cli.nombre, cta.tipocuenta, s.nombre,
       sum( case when t.tipotransaccion='Depósito' then t.monto
       else 0 end ) as despositos,
       sum(case when t.tipotransaccion='Retiro' then t.monto
       else 0 end ) as retiros
from clientes as cli
inner join cuentas as cta on cli.clienteid=cta.clienteid
inner join transacciones as t on cta.cuentaid=t.cuentaid
inner join sucursales as s on cta.sucursalid=s.sucursalid
group by cli.nombre, cta.tipocuenta, s.nombre
order by cli.nombre, s.nombre;

-- ---otra manera.
 select cli.nombre as cliente,
        s.nombre as sucursal,
        cu.tipocuenta ,
        sum(case when tipotransaccion="deposito"then trx.monto else 0 end) as totaldepositos,
		sum(case when tipotransaccion="retiro"then trx.monto else 0 end) as totalretiros
 from clientes cli
 inner join cuentas cu on cli.clienteid=cu.clienteid
 inner join transacciones trx on cu.cuentaid = trx.cuentaid
 inner join sucursales s on cu.sucursalid = s.sucursalid
 group by cli.nombre, s.nombre,tipocuenta;
