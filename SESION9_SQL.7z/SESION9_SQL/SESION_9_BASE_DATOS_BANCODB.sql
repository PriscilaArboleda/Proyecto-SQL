-- Crear la base de datos
CREATE DATABASE BancoDB;
-- Usar la base de datos
USE BancoDB;

-- 1. Crear la tabla de Sucursales
CREATE TABLE Sucursales (
    SucursalID INT PRIMARY KEY,
    Nombre VARCHAR(100),
    Ubicacion VARCHAR(255)
);

-- 2. Crear la tabla de Clientes
CREATE TABLE Clientes (
    ClienteID INT PRIMARY KEY,
    Nombre VARCHAR(100),
    Direccion VARCHAR(255),
    Telefono VARCHAR(15),
    FechaRegistro DATE
);

-- 3. Crear la tabla de Cuentas
CREATE TABLE Cuentas (
    CuentaID INT PRIMARY KEY,
    ClienteID INT,
    SucursalID INT,
    TipoCuenta VARCHAR(50),
    Saldo DECIMAL(15, 2),
    FechaApertura DATE,
    FOREIGN KEY (ClienteID) REFERENCES Clientes(ClienteID),
    FOREIGN KEY (SucursalID) REFERENCES Sucursales(SucursalID)
);

-- 4. Crear la tabla de Transacciones
CREATE TABLE Transacciones (
    TransaccionID INT PRIMARY KEY,
    CuentaID INT,
    FechaTransaccion DATETIME,
    Monto DECIMAL(15, 2),
    TipoTransaccion VARCHAR(50),
    FOREIGN KEY (CuentaID) REFERENCES Cuentas(CuentaID)
);

-- Insertar datos en la tabla de Sucursales
INSERT INTO Sucursales (SucursalID, Nombre, Ubicacion) VALUES
(1, 'Sucursal Centro', 'Av. Principal 123, Ciudad X'),
(2, 'Sucursal Norte', 'Av. Norte 456, Ciudad X'),
(3, 'Sucursal Sur', 'Av. Sur 789, Ciudad Y');

-- Insertar datos en la tabla de Clientes
INSERT INTO Clientes (ClienteID, Nombre, Direccion, Telefono, FechaRegistro) VALUES
(1, 'Juan Pérez', 'Calle Ficticia 12, Ciudad X', '555-1234', '2023-01-15'),
(2, 'Ana Gómez', 'Calle Imaginaria 45, Ciudad X', '555-5678', '2022-06-20'),
(3, 'Carlos Sánchez', 'Calle Real 67, Ciudad Y', '555-9876', '2021-10-05'),
(4, 'María López', 'Calle Nueva 89, Ciudad Y', '555-5432', '2020-08-30'),
(5, 'Laura Pérez', 'Calle Independencia 10, Ciudad Z', '555-6543', '2023-02-10'); -- Cliente sin cuenta bancaria

-- Insertar datos en la tabla de Cuentas
INSERT INTO Cuentas (CuentaID, ClienteID, SucursalID, TipoCuenta, Saldo, FechaApertura) VALUES
(1, 1, 1, 'Ahorros', 5000.00, '2023-01-16'),
(2, 2, 1, 'Corriente', 3000.00, '2022-06-21'),
(3, 3, 2, 'Ahorros', 15000.00, '2021-10-06'),
(4, 4, 3, 'Corriente', 2000.00, '2020-09-01');

-- Insertar datos en la tabla de Transacciones
INSERT INTO Transacciones (TransaccionID, CuentaID, FechaTransaccion, Monto, TipoTransaccion) VALUES
(1, 1, '2023-01-17 10:00:00', 200.00, 'Depósito'),
(2, 1, '2023-02-01 12:30:00', 50.00, 'Retiro'),
(3, 2, '2022-06-22 09:00:00', 500.00, 'Depósito'),
(4, 3, '2021-10-07 14:15:00', 1000.00, 'Retiro'),
(5, 4, '2020-09-02 16:00:00', 100.00, 'Depósito'),
(6, 4, '2021-01-10 11:45:00', 300.00, 'Retiro');

