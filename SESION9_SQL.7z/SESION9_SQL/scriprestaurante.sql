USE restaurante_join;
-- Ejercicio 1: Total de ventas por mesero: Relaciona las tablas Meseros y Reservas mediante MeseroID 
-- utilizando un INNER JOIN para obtener solo aquellos meseros que han atendido reservas.
-- Selecciona los campos Nombre para el nombre del mesero y SUM(r.Total) para calcular el total de ventas generadas 
-- por cada mesero.  Agrupa los resultados por el nombre del mesero y ordena el total de ventas de mayor a menor
select * from meseros;
select * from reservas;

select me.nombre,
	   sum(total) as total_de_ventas
from  meseros as me
inner join reservas as re on me.MeseroID = re.MeseroID
group by me.nombre
order by total_de_ventas desc;

-- Ejercicio 2: Total de ventas por categoría de plato: Relaciona las tablas Platos, 
-- DetallesReservas y Reservas utilizando PlatoID y ReservaID con INNER JOINs para obtener los platos 
-- que han sido vendidos en las reservas. Selecciona la categoría del plato (Categoria)
-- y calcula el total de ventas por categoría utilizando SUM(dr.Cantidad * p.Precio). 
-- Agrupa los resultados por la categoría de plato y ordena las ventas de mayor a menor
select * from detallesreservas;
select * from platos;
select * from reservas;

select pla.categoria, sum(dtre.Cantidad*pla.Precio) as TotalVentasxCategoria
from platos as pla
inner join detallesreservas as dtre on pla.platoID = dtre.PlatoID
inner join reservas as re on dtre.ReservaID=re.ReservaID
group by pla.categoria
order by TotalVentasxCategoria desc;

-- Ejercicio 3: Obtener las reservas con los detalles de los platos servidos:Relaciona las tablas 
--  Reservas, DetallesReservas y Platos usando ReservaID y PlatoID mediante INNER JOINs para obtener
-- solo las reservas que tienen detalles de platos. Selecciona los campos ReservaID, FechaReserva, 
-- HoraReserva, p.Nombre (nombre del plato) y dr.Cantidad (cantidad de platos). 
-- Ordena los resultados por FechaReserva y HoraReserva para mostrar la secuencia de las reservas.

select * from reservas;
select * from platos;
select * from detallesreservas;


select re.reservaID, re.fechareserva, re.horareserva,
       pla.nombre as NombrePlato,
       detr.cantidad as CantidadPlato
from detallesreservas  as detr
inner join reservas as re on detr.reservaid=re.reservaid
inner join platos as pla on detr.platoid=pla.platoid
order by re.fechareserva, re.horareserva;