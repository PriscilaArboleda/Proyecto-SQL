create database prestamos;
use prestamos;

select * from socio;
select * from libro;
select * from sucursal;
select * from prestamo;

-- creación de tablas con pk y fk
create table socio(
id_socio int primary key auto_increment not null,
nombre_socio varchar(50) not null,
telefono varchar(10)
);

create table libro(
id_libro int primary key  auto_increment not null,
titulo varchar(200),
autor varchar(100),
ISBN varchar(13)
);

create table sucursal(
id_sucursal int primary key auto_increment not null,
direccion  varchar (100),
ciudad varchar (50)
);

create table prestamo(
id_prestamo int primary key auto_increment not null,
fecha_prestamo date,
fecha_devolucion date,
id_socio int,
id_libro int,
id_sucursal int,
foreign key (id_socio) references socio(id_socio),
foreign key (id_libro) references libro(id_libro),
foreign key (id_sucursal) references sucursal (id_sucursal)
);


